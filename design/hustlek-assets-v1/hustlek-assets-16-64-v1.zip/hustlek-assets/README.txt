HustleK Asset Pack v1

Contents: 803 concepts at 16, 32, 48 and 64 pixels (3,212 RGBA PNG files).
The four tiers are separately rasterized and receive different information budgets.
They are not shipped as nearest-neighbour copies of one master size.

Style lock:
- large-head / small-body avatar proportions
- selective dark outline
- warm upper-left light and stepped lower-right shade
- no blur, gradient, dither or antialiasing
- integer coordinates and binary alpha only

This is design working material and is not automatically wired into the app.
Source archive SHA-256: 2a5a6a14d81ca22dafd87b9b5f0547312cfac7682b95d74ae263c132b299238e
HustleK atlas decoded RGBA SHA-256: b077a2d1a4c77c320e92a18b92a722f4a2905340e7b1ba27c47d6a0cf2c8cc49
